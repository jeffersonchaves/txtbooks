<?php
	
	$produto1 = array(1,'Iphone'   , 'Eletronico');
	$produto2 = array(2,'Bicicleta', 'Casa');
	$produto3 = array(3,'Televisao', 'Eletronico');

	$produtos = array($produto1, $produto2, $produto3);


	#logica para escrever no arquivo.
	#DICA: use um loop para tarefas repetitivas